namespace Eco.Mods.TechTree
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using Eco.Gameplay.Blocks;
    using Eco.Gameplay.Components;
    using Eco.Gameplay.Components.Auth;
    using Eco.Gameplay.DynamicValues;
    using Eco.Gameplay.Economy;
    using Eco.Gameplay.Housing;
    using Eco.Gameplay.Interactions;
    using Eco.Gameplay.Items;
    using Eco.Gameplay.Minimap;
    using Eco.Gameplay.Objects;
    using Eco.Gameplay.Players;
    using Eco.Gameplay.Property;
    using Eco.Gameplay.Skills;
    using Eco.Gameplay.Systems.TextLinks;
    using Eco.Gameplay.Pipes.LiquidComponents;
    using Eco.Gameplay.Pipes.Gases;
    using Eco.Gameplay.Systems.Tooltip;
    using Eco.Shared;
    using Eco.Shared.Math;
    using Eco.Shared.Localization;
    using Eco.Shared.Serialization;
    using Eco.Shared.Utils;
    using Eco.Shared.View;
    using Eco.Shared.Items;
    using Eco.Gameplay.Pipes;
    using Eco.World.Blocks;
    
    [Serialized]    
    [RequireComponent(typeof(OnOffComponent))]                   
    [RequireComponent(typeof(PropertyAuthComponent))]
    [RequireComponent(typeof(MinimapComponent))]                
    [RequireComponent(typeof(PowerGridComponent))]              
    [RequireComponent(typeof(PowerConsumptionComponent))]                     
    [RequireComponent(typeof(HousingComponent))]                  
    public partial class CeilingFanObject : WorldObject
    {
        // Added FanOn and LightOn so we have 2 switches 
        // which will get saved thanks to the Serialized attribute
        [Serialized] public bool FanOn = true;
        [Serialized] public bool LightOn = true;
        public override string FriendlyName { get { return "Celing Fan"; } }

        protected override void Initialize()
        {
            this.GetComponent<MinimapComponent>().Initialize("Lights");
            // Added custom power consumption
            this.InitPowerConsumption();
            this.GetComponent<PowerGridComponent>().Initialize(10, new ElectricPower());
            this.GetComponent<HousingComponent>().Set(CeilingFanItem.HousingVal);
        }

        // Added this to change power consumed based on if the light & fan are enabled
        public void InitPowerConsumption()
        {
            float power = 0f;
            if (FanOn)
                power += 50f;
            if (LightOn)
                power += 50f;

            this.GetComponent<PowerConsumptionComponent>().Initialize(power);
        }

        // We will be sending the server "Fan" and "Light" when their switches
        // are right clicked, also update the power consumed when switches are toggled
        public override InteractResult OnActRight(InteractionContext context)
        {
            if (context.Parameters != null && context.Parameters.ContainsKey("Fan"))
            {
                FanOn = !FanOn;
                this.InitPowerConsumption();
                return InteractResult.Success;
            }

            if (context.Parameters != null && context.Parameters.ContainsKey("Light"))
            {
                LightOn = !LightOn;
                this.InitPowerConsumption();
                return InteractResult.Success;
            }
            return InteractResult.NoOp;
        }

        // Finally we send the Fan & Light states to clients using Animated States
        // Operating indicates that room/power requirements are fulfilled
        public override void Tick()
        {
            base.Tick();
            SetAnimatedState("Fan", this.Operating && FanOn);
            SetAnimatedState("Light", this.Operating && LightOn);
        }
    }


    [Serialized]
    public partial class CeilingFanItem :
        WorldObjectItem<CeilingFanObject> 
    {
        public override string FriendlyName { get { return "Ceiling Fan"; } } 
        public override string Description  { get { return  "A fan that requires metachronism energy to activate."; } }

        static CeilingFanItem()
        {
            
        }

        [TooltipChildren] public HousingValue HousingTooltip { get { return HousingVal; } }
        [TooltipChildren] public static HousingValue HousingVal { get { return new HousingValue() 
                                                {
                                                    Category = "General",
                                                    Val = 4,                                   
                                                    TypeForRoomLimit = "Lights", 
                                                    DiminishingReturnPercent = 0.8f    
        };}}
    }


    [RequiresSkill(typeof(ElectronicEngineeringSkill), 3)]
    public partial class CeilingFanRecipe : Recipe
    {
        public CeilingFanRecipe()
        {
            this.Products = new CraftingElement[]
            {
                new CraftingElement<CeilingFanItem>(),
            };

            this.Ingredients = new CraftingElement[]
            {
                new CraftingElement<LightBulbItem>(1), 
                new CraftingElement<SteelItem>(typeof(ElectronicEngineeringEfficiencySkill), 10, ElectronicEngineeringEfficiencySkill.MultiplicativeStrategy),   
            };
            SkillModifiedValue value = new SkillModifiedValue(1, ElectronicEngineeringSpeedSkill.MultiplicativeStrategy, typeof(ElectronicEngineeringSpeedSkill), Localizer.DoStr("craft time"));
            SkillModifiedValueManager.AddBenefitForObject(typeof(CeilingFanRecipe), Item.Get<CeilingFanItem>().UILink(), value);
            SkillModifiedValueManager.AddSkillBenefit(Item.Get<CeilingFanItem>().UILink(), value);
            this.CraftMinutes = value;
            this.Initialize("Ceiling Fan", typeof(CeilingFanRecipe));
            CraftingComponent.AddRecipe(typeof(ElectronicsAssemblyObject), this);
        }
    }
}